rmmod task1
rmmod task2
rmmod task3
rmmod sched
cat /proc/modules
