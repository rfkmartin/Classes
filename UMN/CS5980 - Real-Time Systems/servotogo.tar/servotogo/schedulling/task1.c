#include <rtl.h>
#include <time.h>
#include <pthread.h>

#include <stdio.h>
#include <sys/io.h>
#define PORT 0x0340
#define D_DIR 0x407
#define MOTOR 0x405
#define ENCODER_CMD 0x06
#define ENCODER_DATA 0x04
#define CNTRL0 0x401
#define CNTRL1 0x40F
#define ADC_L 0x410
#define ADC_H 0x411
#define BRDTEST 0x403

pthread_t thread;
void * start_routine(void *arg) {
   struct sched_param p;
   int i,j;	
	
   p.sched_priority = 1;
   pthread_setschedparam (pthread_self(), SCHED_FIFO, &p);
   pthread_make_periodic_np (pthread_self(), gethrtime(),
                             50000000);

   while (1) {
		for(i=0; i<26; i++){
			rtl_printf("%c",'A');
		}

     pthread_wait_np();
   }
   return 0;
}

int init_module(void) {
   return pthread_create (&thread, NULL, start_routine, 0);
}

void cleanup_module(void) {
   pthread_cancel (thread);
   pthread_join (thread, NULL);
}
