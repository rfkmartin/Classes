#include <rtl.h>
#include <time.h>
#include <pthread.h>

#include <stdio.h>
#include <sys/io.h>
#define PORT 0x0340
#define D_DIR 0x407
#define MOTOR 0x405
#define ENCODER_CMD 0x06
#define ENCODER_DATA 0x04
#define CNTRL0 0x401
#define CNTRL1 0x40F
#define ADC_L 0x410
#define ADC_H 0x411
#define BRDTEST 0x403

pthread_t thread;
void * start_routine(void *arg) {
   struct sched_param p;
        int i,j,k,err;	
	unsigned char data_write;	
	unsigned char data_read,data_read1,data_read2,data_read_p = 1;	
	short dir_data;	
	short motor_data;	
	short verify=0; 	
	float f;	
	int eoc = 1;	
	int rotation_cnt = 1;
	
   	p.sched_priority = 1;
   	pthread_setschedparam (pthread_self(), SCHED_FIFO, &p);
   	pthread_make_periodic_np (pthread_self(), gethrtime(),
                             500000);
        /* added code from polling */

        /* for encoder initialization */
	data_write = 0x20;
	outb(data_write,PORT+ENCODER_CMD);
	data_write = 0x68;
	outb(data_write,PORT+ENCODER_CMD);
	data_write = 0x80;
	outb(data_write,PORT+ENCODER_CMD);
	data_write = 0xC3;
	outb(data_write,PORT+ENCODER_CMD);
	
		
	rtl_printf("\n----------------------------------------\n");
	  
  	
	/* read encoder data */	
	/*set the output of encoder latch */
	data_write = 0x03;
	outb(data_write,PORT+ENCODER_CMD);
	rtl_printf("data read by encoder before motor starts\n");
	data_read = inb(PORT+ENCODER_DATA);
	rtl_printf(" %x - ",data_read);
	data_read = inb(PORT+ENCODER_DATA);
	rtl_printf(" %x - ",data_read);
	data_read = inb(PORT+ENCODER_DATA);
	rtl_printf(" %x \n ",data_read);   

	/* motor code*/	
	/*determine the direction of port D*/	
	dir_data = 0x82;	
	outb(dir_data,PORT+D_DIR);        
		
	/*motor start code*/
	motor_data = 0x05;        
	outb(motor_data,PORT+MOTOR);

   while (1) {
               /* Keep polling */
               /*while (rotation_cnt != 0)*/

		/* reading the signal from wheel */
	        data_read = inb(PORT+BRDTEST); 	    
		data_read = data_read & 0x02;

		/* if the transition occured decrement rotation count*/
		if(data_read == 0 && data_read_p != 0){
			rotation_cnt = rotation_cnt - 1; 	
        		rtl_printf("%d\n",rotation_cnt);
		}
		
		data_read_p = data_read;

		if(rotation_cnt == 0){
			/*stop motor*/
		    	motor_data = 0x00;	
		    	outb(motor_data,PORT+MOTOR);

		    	/* read encoder data */	
		    	/* set the output of encoder latch */
		    	data_write = 0x03;
		    	outb(data_write,PORT+ENCODER_CMD);
		    	rtl_printf("data read by encoder after motor stops\n");
		    	data_read = inb(PORT+ENCODER_DATA);
		    	data_read1 = inb(PORT+ENCODER_DATA);
		    	data_read2 = inb(PORT+ENCODER_DATA);
		    	/* end of code from polling */

         		motor_data = data_read + data_read1*16*16 + data_read2 * 16*16*16*16;
        		rtl_printf("motor position = %d\n",motor_data);

			break;
  		}

	/*wait till next scheduling burst*/
     	pthread_wait_np();
   }
   return 0;
}

int init_module(void) {
   return pthread_create (&thread, NULL, start_routine, 0);
}

void cleanup_module(void) {
   pthread_cancel (thread);
   pthread_join (thread, NULL);
}
