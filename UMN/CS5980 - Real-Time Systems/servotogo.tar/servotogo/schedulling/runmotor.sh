rmmod sched
rmmod task1.o
rmmod task2.o
rmmod task3.o
insmod sched.o
insmod task2.o
insmod task3.o
cat /proc/modules

