#include <stdio.h>
#include <sys/io.h>
#include <rtl.h>
#include <rtl_core.h>
#include <time.h>
#include <rtl_sync.h>

#define PORT 0x0340
#define D_DIR 0x407
#define MOTOR 0x405
#define ENCODER_CMD 0x06
#define ENCODER_DATA 0x04
#define CNTRL0 0x401
#define CNTRL1 0x40f
#define ADC_L 0x410
#define ADC_H 0x411
#define BRDTEST 0x403

#define TMRCMD 0x40e
#define TIMER2 0x40c

unsigned int  motor_handler(unsigned int irq , struct pt_regs *p)
	  {
	    int intL = 0;
	    unsigned char data_read;
	    rtl_printf("<1> int received\n");
	    
 	    data_read = inb(PORT+CNTRL1); 
	    intL = data_read & 0x20;
	    rtl_printf("%x\n",intL);
	    return 0;
	  }

int init_module()
{
	int err;
	unsigned char data_write;

	short dir_data;
	short motor_data;
	int intL = 0;
	unsigned char data_read;

	/* setting direction of Port D */
	dir_data = 0x82;
	outb(dir_data,PORT+D_DIR);

	/* setting interrupt ReQ Num 10*/
	data_write = 0xcd; 
	outb(data_write,PORT+CNTRL0);
	
	/* enabling interrupt */
	data_write = 0x00;
	outb(data_write,PORT+CNTRL1);


	/* setting the timer */

	data_write = 0x9A;
	outb(data_write,PORT+TMRCMD);
	
	/* setting timer value to 01*/
	data_write = 01;
	outb(data_write,PORT+TIMER2);
	

 	data_read = inb(PORT+CNTRL1); 
	intL = data_read & 0x20;
	rtl_printf("init  %x\n",intL);
	rtl_free_irq(10);

        rtl_printf("int handler installed\n");     
	return rtl_request_irq(10,   /* The number of the reserved IRQ on ISA */
              motor_handler); /* our handler */

}

void cleanup_module()
{
  rtl_printf("module removed\n");   
        rtl_free_irq(10);
	   
}



