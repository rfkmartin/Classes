#include <stdio.h>
#include <sys/io.h>

#define PORT 0x0340
#define D_DIR 0x407
#define MOTOR 0x405
#define ENCODER_CMD 0x06
#define ENCODER_DATA 0x04
#define CNTRL0 0x401
#define ADC_L 0x410
#define ADC_H 0x411
#define BRDTEST 0x403

int main()
{	
	int i,j,k,err;	
	unsigned char data_write;	
	unsigned char data_read,data_read1,data_read2,data_read_p = 2;	
	short dir_data;	
	short motor_data;	
	
	int rotation_cnt = 1;	
	err = iopl(3); 

	/* for encoder initialization 
	data_write = 0x20;
	outb(data_write,PORT+ENCODER_CMD);
	data_write = 0x68;
	outb(data_write,PORT+ENCODER_CMD);
	data_write = 0x80;
	outb(data_write,PORT+ENCODER_CMD);
	data_write = 0xC3;
	outb(data_write,PORT+ENCODER_CMD);
*/

	/* read encoder data */	
	/*set the output of encoder latch */
	data_write = 0x03;
	outb(data_write,PORT+ENCODER_CMD);
	printf("data read by encoder before motor starts\n");
	data_read = inb(PORT+ENCODER_DATA);
	printf(" %x - ",data_read);
	data_read = inb(PORT+ENCODER_DATA);
	printf(" %x - ",data_read);
	data_read = inb(PORT+ENCODER_DATA);
	printf(" %x \n",data_read);   

	/* motor code*/	
	/*determine the direction of port D*/	
	dir_data = 0x82;	
	outb(dir_data,PORT+D_DIR);        
		
	motor_data = 0x05;        
	outb(motor_data,PORT+MOTOR);
	printf("motor starts\n");	
	
	/* Keep polling */
	while (rotation_cnt != 0)	
	{
	        data_read = inb(PORT+BRDTEST); 	    
		data_read = data_read & 0x02;
		
		if((data_read == 0) && (data_read_p != 0))
		  {	
			rotation_cnt = rotation_cnt - 1; 	
			printf("%d\n",rotation_cnt);
		  }
		data_read_p = data_read;
	}

	motor_data = 0x00;	
	outb(motor_data,PORT+MOTOR);

	/* read encoder data */	
	/* set the output of encoder latch */
	data_write = 0x03;
	outb(data_write,PORT+ENCODER_CMD);
	data_read = inb(PORT+ENCODER_DATA);
	data_read1 = inb(PORT+ENCODER_DATA);
	data_read2 = inb(PORT+ENCODER_DATA);

	printf("After motor stops\n");
        motor_data = data_read + data_read1*16*16 + data_read2*16*16*16*16;
        printf("motor position = %d\n",motor_data);
}
