        #if defined(CONFIG_MODVERSIONS) && ! defined(MODVERSIONS)
           #include <linux/modversions.h>
           #define MODVERSIONS
        #endif
        #include <linux/kernel.h>
        #include <linux/module.h>
        #include <linux/fs.h>
        #include <asm/uaccess.h>  /* for put_user */

#include <rtl.h>
#include <rtl_posixio.h>
#include <sys/io.h>

#define PORT 0x0340
#define D_DIR 0x407
#define MOTOR 0x405
#define ENCODER_CMD 0x06
#define ENCODER_DATA 0x04
#define CNTRL0 0x401
#define ADC_L 0x410
#define ADC_H 0x411
#define BRDTEST 0x403

        #define SUCCESS 0
        #define DEVICE_NAME "motor" /* Dev name as it appears in /proc/devices   */
        #define BUF_LEN 80            /* Max length of the message from the device */
                                                                                                                             
	int init_module(void);
	void cleanup_module(void);
	static int rtl_motor_open(struct rtl_file *filp);
	static int rtl_motor_release(struct rtl_file *filp);
	static ssize_t rtl_motor_read(struct rtl_file *filp,
                            char *buf, size_t count,
                            off_t* ppos);
	static ssize_t rtl_motor_write(struct rtl_file *filp,
                             const char *buf,
                             size_t count, off_t* ppos);
	static int rtl_motor_ioctl(struct rtl_file *filp,
                         unsigned int request,
                         unsigned long l);

        static int Major;            /* Major number assigned to our device driver */
        static int Device_Open = 0;  /* Is device open?  Used to prevent multiple
                                        access to the device                       */
        static char msg[BUF_LEN];    /* The msg the device will give when asked    */
        static char *msg_Ptr;

        static struct file_operations fops = {
          .read = rtl_motor_read,
          .write = rtl_motor_write,
          .open = rtl_motor_open,
          .release = rtl_motor_release
        };

char out_byte;

        int init_module(void)
        {
		short dir_data;
		unsigned char data_write;
		unsigned char data_read,data_read1,data_read2;

           	Major = register_chrdev(0, DEVICE_NAME, &fops);
                                                                                                                             
		/*port D initialization */
		dir_data = 0x82;
		outb(dir_data,PORT+D_DIR);

		/* for encoder initialization */
        	data_write = 0x20;
        	outb(data_write,PORT+ENCODER_CMD);
        	data_write = 0x68;
        	outb(data_write,PORT+ENCODER_CMD);
        	data_write = 0x80;
        	outb(data_write,PORT+ENCODER_CMD);
        	data_write = 0xC3;
        	outb(data_write,PORT+ENCODER_CMD);

        	
        	data_read = inb(PORT+ENCODER_DATA);
        	data_read1 = inb(PORT+ENCODER_DATA);
        	data_read2 = inb(PORT+ENCODER_DATA);
		
		data_write = 0x03;
        	outb(data_write,PORT+ENCODER_CMD);
		rtl_printf("\n\n------------------------\n");
		rtl_printf("motor intialized\n");
		rtl_printf("this is the %x %x %x\n",data_read,data_read1,data_read2);

        	/*cntrl0 for ADC */
        	data_write = 0xc8;
        	outb(data_write,PORT+CNTRL0);

           	if (Major < 0) {
             		printk ("Registering the character device failed with %d\n", Major);
             		return Major;
           	}
                                                                                                                             
                                                                                                                             
           return 0;
        }
                                                                                                                             
                                                                                                                             
        void cleanup_module(void)
        {
           /* Unregister the device */
           int ret = unregister_chrdev(Major, DEVICE_NAME);
           if (ret < 0) printk("Error in unregister_chrdev: %d\n", ret);
        }

static int rtl_motor_open(struct rtl_file *filp)
{

	rtl_printf("motor opened\n");
	return 0;
}

static int rtl_motor_release(struct rtl_file *filp)
{
	rtl_printf("motor released\n");
	return 0;
}


static ssize_t rtl_motor_read(struct rtl_file *filp,
			    char *buf, size_t count,
			    off_t* ppos)
{
	int eoc = 1;
	short dir_data;
	unsigned char data_write,data_read,data_read1,data_read2;

	rtl_printf("read option = %d\n",count);
	switch(count){
	case 1:
        	/*start conversion */
        	dir_data = 0x0000;
        	outw(data_write,PORT+ADC_L);
        	/* wait for EOC */
        	while(eoc != 0)
          	{
            		data_read = inb(PORT+BRDTEST);
            		eoc = data_read & 0x08;
          	}
        	/* read data */
        	dir_data = inw(PORT+ADC_L);
        	dir_data = dir_data & 0x1FFF;
		rtl_printf("this is the POT =  %x\n",dir_data);
		return dir_data;
	case 2:
	        
        	data_read = inb(PORT+ENCODER_DATA);
        	data_read1 = inb(PORT+ENCODER_DATA);
        	data_read2 = inb(PORT+ENCODER_DATA);
        	data_write = 0x03;
        	outb(data_write,PORT+ENCODER_CMD);
		rtl_printf("this is the %x- %x- %x\n",data_read,data_read1,data_read2);
		rtl_printf("this is the %d\n",data_read+data_read1*16*16+data_read2*16*16*16*16);
	
		return(data_read+data_read1*16*16+data_read2*16*16*16*16);
	default:
		return 0;
	}
}

static ssize_t rtl_motor_write(struct rtl_file *filp,
			     const char *buf,
			     size_t count, off_t* ppos)
{
	short dir_data;
	short motor_data;
	

        rtl_printf("motor starts, count = %d\n",count);
	switch(count){
	case 0:
		motor_data = 0x00;
		break;
	case 1:
		motor_data = 0x05;
		break;
	case 2:
		motor_data = 0x06;
		break;
	}

        outb(motor_data,PORT+MOTOR);

	return 0;
}

static int rtl_motor_ioctl(struct rtl_file *filp,
			 unsigned int request,
			 unsigned long l)
{
	switch ( request )
	{
	case 0:
		out_byte |= 1<<l;
		break;
	case 1:
		out_byte &= ~(1<<l);
		break;
	default:
		return -EINVAL;
	}
	outb( out_byte, PORT );
	return 0;
}
