#include <sys/stat.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>

int main(){
	int fd;
	int op = 0;
	int rd1,rd2,fdchr;
	char buff[256];

	//open the motor device
	fd = open("/dev/motor",1);
	if(fd<0){
		printf("The motor could not be opened\n");
	}

	//start the motor
	printf("Enter the motor operation\n");
	printf("[0] Stop the motor\n");
	printf("[1] Start motor in forward direction\n");
	printf("[2] Start motor in reverse direction\n");
	printf("[3] Exit\n");
	while(1){
		printf("Enter the motor operation\n");
		scanf("%d",&op);
		if(op == 3) break;
		write(fd,buff,op);
	}
	close(fd);

	fd = open("/dev/motor",4);
	rd1 = read(fd,buff,1);
	rd2 = read(fd,buff,2);
	printf("Potentiometer reading = %x\n", rd1);
	printf("Encoder reading= %d\n",rd2);
	close(fd);
}

